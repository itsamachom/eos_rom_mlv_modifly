# FIRMWARE ADD-ON Thai-Menu v3r4 — camera update

Canon EOS 600D / Canon firmware 1.0.2 only. Public Experimental, not Stable.
For cameras already running Magic Lantern. This ZIP is not a first-install kit: it contains no FIR installer or source archive.

Back up the card, turn off the camera and use a card reader. Extract this ZIP on the computer and replace autoexec.bin and the entire ML/ directory at the card root. Avoid adding another folder layer. Turn on the camera and check Setup (+) > Version: Thai-Menu v3r4. Do not run Firmware Update again for this menu update. Do not put the source ZIP on the card.

Runtime files are byte-identical to the tagged Full v3r4 package; no firmware rebuild was performed. Camera/QEMU and first-install testing are not claimed for this version.

Project: https://itsamachom.github.io/eos_rom_mlv_modifly/
Matching source: https://raw.githubusercontent.com/itsamachom/eos_rom_mlv_modifly/v3r4/deliveries/photo-ui-v3r4-full/600D-PHOTO-UI-v3r4-source.zip
Source ZIP SHA256: 77564f9ebc11e5a5f219bd4dd511bd83a39c9a6bb250446724d910612397022d

Preserve all notices. Inherited dietlibc corresponding source remains unverified; see SOURCE.txt, THIRD_PARTY_NOTICES.md and the included provenance records. Experimental status does not resolve the source audit.
