# FIRMWARE ADD-ON Thai-Menu v3r4 — อัปเดตกล้องที่มี ML แล้ว

สำหรับ Canon EOS 600D / Canon firmware 1.0.2 เท่านั้น เป็น Experimental ไม่ใช่ Stable

แพ็กเกจนี้เป็นไฟล์อัปเดตเมนูสำหรับกล้องที่ติดตั้ง Magic Lantern และใช้งานอยู่แล้ว ไม่รวม Source ZIP หรือตัวติดตั้ง .FIR สำหรับเริ่มติดตั้ง ML ครั้งแรก

1. สำรองไฟล์ในการ์ดก่อน รวมถึง autoexec.bin และ ML/ เดิม
2. ปิดกล้องและใช้ card reader แตกไฟล์ ZIP ลงคอมพิวเตอร์
3. นำ autoexec.bin และโฟลเดอร์ ML/ ทั้งชุดไปแทนที่ที่รากการ์ด อย่าวางซ้อนในโฟลเดอร์ ZIP อีกชั้น
4. นำการ์ดกลับเข้ากล้อง เปิดและตรวจ + → เวอร์ชั่น: Thai-Menu v3r4
5. ไม่เรียก Firmware Update ซ้ำเพื่ออัปเดตเมนู และไม่นำ Source ZIP ไปลงการ์ด

หากยังไม่มี ML บนกล้อง อย่าใช้แพ็กเกจนี้เป็นตัวติดตั้งครั้งแรก รุ่นนี้ยังไม่ผ่านการทดสอบการติดตั้งครั้งแรกใหม่หรือการทดสอบฮาร์ดแวร์ v3r4

ไฟล์ autoexec.bin และ ML/ ตรงกับ Full v3r4 เดิมทุกไบต์ ไม่มีการ rebuild หรือแก้เฟิร์มแวร์ในขั้นตอนแยกแพ็กเกจ

เว็บไซต์: https://itsamachom.github.io/eos_rom_mlv_modifly/
ซอร์สที่ตรงกัน: https://raw.githubusercontent.com/itsamachom/eos_rom_mlv_modifly/v3r4/deliveries/photo-ui-v3r4-full/600D-PHOTO-UI-v3r4-source.zip
SHA256 source ZIP: 77564f9ebc11e5a5f219bd4dd511bd83a39c9a6bb250446724d910612397022d

ดู SOURCE.txt, THIRD_PARTY_NOTICES.md และ release/v3r2/PROVENANCE.md สำหรับเครดิตและข้อจำกัด corresponding source ของ inherited dietlibc ที่ยังไม่ถูกยืนยัน เก็บประกาศลิขสิทธิ์และใบอนุญาตเดิม
